package com.example.weighttrackingapp_janaiwilliams;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// Connects weight data to the RecyclerView
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private final List<WeightEntry> weights;
    private final DataGridActivity parentActivity;

    public WeightAdapter(List<WeightEntry> weights, DataGridActivity parentActivity) {
        this.weights = weights;
        this.parentActivity = parentActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weights.get(position);

        holder.textDate.setText(entry.getDate());
        holder.textWeight.setText(entry.getWeight());

        // Edit entry when button is clicked
        holder.buttonEdit.setOnClickListener(v ->
                parentActivity.showEditDialog(entry.getDate(), entry.getWeight())
        );

        // Delete entry when button is clicked
        holder.buttonDelete.setOnClickListener(v -> {
            parentActivity.deleteEntry(entry.getDate());
            weights.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return weights.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textDate, textWeight;
        Button buttonEdit, buttonDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
