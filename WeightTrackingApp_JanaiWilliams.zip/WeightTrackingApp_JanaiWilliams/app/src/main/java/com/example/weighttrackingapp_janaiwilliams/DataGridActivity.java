package com.example.weighttrackingapp_janaiwilliams;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

// Displays weight data in a RecyclerView grid
public class DataGridActivity extends AppCompatActivity {

    private RecyclerView recyclerViewWeights;
    private EditText editTextDate, editTextWeight;
    private WeightAdapter weightAdapter;
    private List<WeightEntry> weightList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // Link layout elements
        recyclerViewWeights = findViewById(R.id.recyclerViewWeights);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);

        // Set up database and list
        dbHelper = new DatabaseHelper(this);
        weightList = new ArrayList<>();

        // Configure RecyclerView
        recyclerViewWeights.setLayoutManager(new LinearLayoutManager(this));
        weightAdapter = new WeightAdapter(weightList, this);
        recyclerViewWeights.setAdapter(weightAdapter);

        // Load existing weights from database
        loadWeightsFromDB();

        // Open date picker when clicking on date field
        editTextDate.setOnClickListener(v -> openDatePicker());
    }

    // Opens a calendar picker for selecting the date
    private void openDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String selectedDate = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                    editTextDate.setText(selectedDate);
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    // Loads all saved weights from the database
    private void loadWeightsFromDB() {
        weightList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT date, weight FROM weights", null);

        while (cursor.moveToNext()) {
            weightList.add(new WeightEntry(cursor.getString(0), cursor.getString(1)));
        }
        cursor.close();
        db.close();
        weightAdapter.notifyDataSetChanged();
    }

    // Adds new record when "Add Entry" button is pressed
    public void onAddEntryClick(View view) {
        String date = editTextDate.getText().toString().trim();
        String weight = editTextWeight.getText().toString().trim();

        if (date.isEmpty() || weight.isEmpty()) {
            Toast.makeText(this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO weights (date, weight) VALUES (?, ?)", new Object[]{date, weight});
        db.close();

        // Refresh list after adding new entry
        loadWeightsFromDB();

        editTextDate.setText("");
        editTextWeight.setText("");

        Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();
    }

    // Deletes a record from the database
    public void deleteEntry(String date) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM weights WHERE date=?", new Object[]{date});
        db.close();

        loadWeightsFromDB();
        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
    }

    // Updates an existing weight by date
    public void updateEntry(String date, String newWeight) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("UPDATE weights SET weight=? WHERE date=?", new Object[]{newWeight, date});
        db.close();

        loadWeightsFromDB();
        Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show();
    }

    // Opens a small dialog to edit an existing weight entry
    public void showEditDialog(String date, String currentWeight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Entry for " + date);

        final EditText input = new EditText(this);
        input.setHint("Enter new weight");
        input.setText(currentWeight);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setPadding(40, 30, 40, 30);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newWeight = input.getText().toString().trim();
            if (!newWeight.isEmpty()) {
                updateEntry(date, newWeight);
            } else {
                Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Go back to previous screen
    public void onBackClick(View view) {
        finish();
    }

    // Return to the Login screen
    public void onHomeClick(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
