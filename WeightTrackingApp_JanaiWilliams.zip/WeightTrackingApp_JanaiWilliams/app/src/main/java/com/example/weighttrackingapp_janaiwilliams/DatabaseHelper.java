package com.example.weighttrackingapp_janaiwilliams;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Handles database creation and version management
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "weighttracker.db"; // Database name
    private static final int DB_VERSION = 1; // Database version number

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Called once when the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight REAL)");
        db.execSQL("CREATE TABLE goal (id INTEGER PRIMARY KEY AUTOINCREMENT, goalWeight REAL)");
    }

    // Called when the database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }
}
