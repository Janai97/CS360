package com.example.weighttrackingapp_janaiwilliams;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.Calendar;

// Handles goal weight saving, date selection, and SMS notifications
public class GoalActivity extends AppCompatActivity {

    EditText goalWeightEditText, goalDateEditText;
    Spinner weightUnitSpinner;
    TextView textNotificationStatus;
    Button buttonEnableSMS, buttonSaveGoal;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        // Connect layout elements
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        goalDateEditText = findViewById(R.id.goalDateEditText);
        weightUnitSpinner = findViewById(R.id.weightUnitSpinner);
        textNotificationStatus = findViewById(R.id.textNotificationStatus);
        buttonEnableSMS = findViewById(R.id.buttonEnableSMS);
        buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        dbHelper = new DatabaseHelper(this);

        // Open date picker when date field is tapped
        goalDateEditText.setOnClickListener(v -> openDatePicker());

        // Save goal when clicked
        buttonSaveGoal.setOnClickListener(v -> saveGoal());

        // Enable SMS notifications when clicked
        buttonEnableSMS.setOnClickListener(v -> checkSMSPermission());
    }

    // Opens a calendar date picker
    private void openDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String selectedDate = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                    goalDateEditText.setText(selectedDate);
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    // Saves goal weight, unit, and target date to database
    private void saveGoal() {
        String goalText = goalWeightEditText.getText().toString().trim();
        String goalDate = goalDateEditText.getText().toString().trim();
        String selectedUnit = weightUnitSpinner.getSelectedItem().toString();

        if (goalText.isEmpty() || goalDate.isEmpty()) {
            Toast.makeText(this, "Please enter your goal weight and target date", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO goal (goalWeight) VALUES (?)", new Object[]{goalText + " " + selectedUnit});
        Toast.makeText(this, "Goal saved for " + goalDate + "!", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, DataGridActivity.class)); // Redirect to Daily Weights
    }

    // Check and request SMS permission
    private void checkSMSPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            sendGoalReachedSMS();
        }
    }

    // Sends an SMS alert if permissions are granted
    private void sendGoalReachedSMS() {
        SmsManager sms = getSystemService(SmsManager.class);
        sms.sendTextMessage("5554", null,
                "Congratulations! You reached your goal weight!",
                null, null);
        textNotificationStatus.setText(R.string.notifications_on);
        Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
    }

}
