package com.example.weighttrackingapp_janaiwilliams;

// Model class that holds a single weight entry
public class WeightEntry {
    private final String date;
    private final String weight;

    public WeightEntry(String date, String weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }
}
